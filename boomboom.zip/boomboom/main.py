import streamlit as st
import nltk # type: ignore
from nltk.tokenize import word_tokenize # type: ignore
from nltk.corpus import wordnet as wn # type: ignore

# Function to find ambiguous words
def find_ambiguous_words(text):
    # Tokenize the text into words
    words = word_tokenize(text)
    ambiguous_words = {}
    for word in words:
        # Check if the word has multiple synsets (i.e., multiple senses)
        synsets = wn.synsets(word)
        if len(synsets) > 1:
            ambiguous_words[word] = [syn.definition() for syn in synsets]
    return ambiguous_words

# Function to load a dataset
def load_dataset(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        dataset = file.read()
    return dataset

# Streamlit app
def main():
    # Download required NLTK resources
    nltk.download('punkt')
    nltk.download('wordnet')

    # Title and instructions
    st.title("Word Sense Disambiguation")
    st.write("Please input a paragraph or a sentence:")

    # Input field for user input
    user_input = st.text_area("Input Text")

    # Button to trigger analysis
    if st.button("Analyze"):
        # Perform analysis on user input
        ambiguous_words = find_ambiguous_words(user_input)
        if ambiguous_words:
            st.write("Ambiguous words in the text:")
            for word, meanings in ambiguous_words.items():
                st.write(f"- '{word}':")
                for i, meaning in enumerate(meanings, start=1):
                    st.write(f"  {i}. {meaning}")
        else:
            st.write("No ambiguous words found in the text.")

# Run the app
if __name__ == "__main__":
    main()
